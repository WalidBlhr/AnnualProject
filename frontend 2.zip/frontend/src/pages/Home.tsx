import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const Home: React.FC = () => {
    const { user } = useAuth();

    return (
        <div>
            {user ? (
                <h1>
                    Bonjour {user.firstName} {user.lastName}
                </h1>
            ) : (
                <h1>Welcome, please log in or sign up.</h1>
            )}
        </div>
    );
};

export default Home;