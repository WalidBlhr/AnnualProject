import React, { createContext, useState, useContext, ReactNode } from 'react';

interface User {
    firstName: string;
    lastName: string;
    email: string;
}

interface AuthContextType {
    user: User | null;
    signup: (user: User, password: string) => void;
    login: (email: string, password: string) => void;
    logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
    const [user, setUser] = useState<User | null>(() => {
        const storedUser = localStorage.getItem('user');
        return storedUser ? JSON.parse(storedUser) : null;
    });

    const signup = (newUser: User, _password: string) => {
        localStorage.setItem('user', JSON.stringify(newUser));
        setUser(newUser);
    };

    const login = (email: string, _password: string) => {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            const parsedUser = JSON.parse(storedUser);
            if (parsedUser.email === email) {
                setUser(parsedUser);
            }
        }
    };

    const logout = () => {
        localStorage.removeItem('user');
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, signup, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) throw new Error('useAuth must be used within AuthProvider');
    return context;
};